CREATE TABLE prueba (
    id INT (2) PRIMARY KEY NOT NULL,
    name VARCHAR (50) NOT NULL,
    last_name VARCHAR (50) NOT NULL,
    rut VARCHAR(20) NOT NULL,
    status VARCHAR NOT NULL
);