function load(){
    var user_id = $id;
     $.ajax({
     url: "vendor/action/add_usuario.php",
     data: parametros,
     beforeSend: function(objeto){
     $("#result").html("Mensaje: Cargando...");
     },
     success: function(datos){
     $("#result").html(datos);
     }
    });
}